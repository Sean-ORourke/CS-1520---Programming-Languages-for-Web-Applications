more JavaScript code samples
